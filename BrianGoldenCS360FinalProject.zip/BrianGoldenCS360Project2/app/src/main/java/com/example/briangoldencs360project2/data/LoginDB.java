package com.example.briangoldencs360project2.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginDB extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "logins.db"; // name of the DB
    private static final int VERSION = 1;

    public static  final class LoginTable{ // helper to keep consistency
        public static final String TABLE = "logins";
        public static final String COL_ID = "_id";
        public static final String COL_NAME = "name";
        public static final String COL_PASSWORD = "password";
     }

    public LoginDB(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){ // DB creation
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement," +
                LoginTable.COL_NAME + " TEXT," +
                LoginTable.COL_PASSWORD + " TEXT)");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        // This would be necessary in any other app but this one is not necessary

    }
}
