package com.example.briangoldencs360project2;

import android.Manifest;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class permissionsActivity extends AppCompatActivity {
    private static final int PERMISSION_SEND_SMS = 123;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions);
    }

    public void onSavePermissions(View view){
        TextView phoneText = findViewById(R.id.editTextPhone);
        RadioButton yesBut = findViewById(R.id.yesRadio);
        RadioButton noBut = findViewById(R.id.noRadio);
        String phoneNumber = phoneText.getText().toString();
        if(phoneNumber.length() != 10){ // check if the phone number is added
            new OKDialog("Please enter a valid Phone Number").show(getSupportFragmentManager(), OKDialog.TAG);
            return;
        }

        if(yesBut.isChecked()){
            ActivityCompat.requestPermissions(permissionsActivity.this,
                    new String[]{Manifest.permission.SEND_SMS},PERMISSION_SEND_SMS); // ask for text permissions
        } else if(noBut.isChecked()){
            // Do nothing
        }else{
            new OKDialog("You need to Select Yes or No").show(getSupportFragmentManager(), OKDialog.TAG); // error checking
        }
    }
}