package com.example.briangoldencs360project2.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class EventDB extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "events.db"; // name of the DB
    private static final int VERSION = 1; // version

    public static  final class EventTable{ // table of values just to help with consistency
        public static final String TABLE = "events";
        public static final String COL_ID = "_id";
        public static final String COL_NAME = "name";
        public static final String COL_DATE = "date";
        public static final String COL_TIME = "time";
        public static final String COL_DESC = "description";
    }
    public EventDB(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){ // DB creation
        db.execSQL("create table " + EventTable.TABLE + " (" +
                EventTable.COL_ID + " integer primary key autoincrement," +
                EventTable.COL_NAME + " TEXT," +
                EventTable.COL_DATE + " TEXT," +
                EventTable.COL_TIME + " TEXT," +
                EventTable.COL_DESC + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        // This would be necessary in any other app but this one is not necessary
    }

}
