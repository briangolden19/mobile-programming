package com.example.briangoldencs360project2;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

/**
 * This class just helps create a Dialog Fragment that does is more of an alert that needs a user to say OK
 */
public class OKDialog extends DialogFragment {
    public static String TAG = "OKDialog";
    private final String displayMessage;

    public OKDialog(String message){
        super();
        displayMessage = message;
    }
    @NonNull
    public Dialog onCreateDialog(Bundle savedInstance){
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(displayMessage)
                .setNeutralButton("Ok", (dialog, id) -> {
                    //do nothing
                });
        // Create the AlertDialog object and return it
        return builder.create();
    }
}
