package com.example.briangoldencs360project2;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import com.example.briangoldencs360project2.data.EventDB;

public class editEvent extends AppCompatActivity implements YesNoDialog.YesNoDialogListener {

    private EventDB eventDBHelper;
    private UserEvent eventToEdit;
    private boolean isEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);
        eventDBHelper = new EventDB(getApplicationContext()); // create our DB helper
        Bundle extras = getIntent().getExtras(); // get any extras
        if(extras != null){ // if we have some extras we are in edit mode
            eventToEdit = GridScreen.userEvents.get(extras.getInt("EventID")); // set our Event to edit
            isEdit = true; // set this, is used in the save button click
            populateEdit(); // populate the screen based on data
        }else{
            isEdit = false; // set this to false if not editing and creating new
        }
    }

    //On Save Button Clicked
    public void onSavedClick(View view){
        TextView editName = findViewById(R.id.editNameText); // get Text views
        TextView editDesc = findViewById(R.id.editDescText);
        TextView editDate = findViewById(R.id.editDateText);
        TextView editTime = findViewById(R.id.editTimeText);

        String nameString = editName.getText().toString(); // get the Strings from the text views
        String descString = editDesc.getText().toString();
        String timeString = editTime.getText().toString();
        String dateString = editDate.getText().toString();

        // Doing checks to make sure format is correct or they are not blank
        if(nameString.isEmpty()){
            new OKDialog("Please enter a valid event name!").show(getSupportFragmentManager(), OKDialog.TAG);
            return;
        }
        if(descString.isEmpty()){
            new OKDialog("Please enter a valid description!").show(getSupportFragmentManager(), OKDialog.TAG);
            return;
        }
        if(timeString.isEmpty() || (timeString.charAt(2) != ':' && (timeString.charAt(5) != 'P' ||
                timeString.charAt(5)!= 'A') || timeString.charAt(6) != 'M')){
            new OKDialog("Please Enter a valid Time. Correct format is 00:00AM").show(getSupportFragmentManager(), OKDialog.TAG);
            return;
        }
        if(dateString.isEmpty() || dateString.charAt(2) != '/' || dateString.charAt(5) != '/' || dateString.length() != 10){
            new OKDialog("Please Enter a valid Date. Correct format is 11/11/1111").show(getSupportFragmentManager(), OKDialog.TAG);
            return;
        }
        SQLiteDatabase writeEventDB = eventDBHelper.getWritableDatabase(); // get the writable DB
        ContentValues values = new ContentValues(); // create our content object
        values.put(EventDB.EventTable.COL_NAME, nameString); // put our name
        values.put(EventDB.EventTable.COL_DATE, dateString); // put our date
        values.put(EventDB.EventTable.COL_TIME, timeString); // put our time
        values.put(EventDB.EventTable.COL_DESC, descString); // put our description
        if(!isEdit) { // if we are not editing
            long added = writeEventDB.insert(EventDB.EventTable.TABLE, null, values); // insert into DB
            if (added != -1) { // if we were able to add this, say we did and go back to the previous activity
                Toast.makeText(getApplicationContext(), "Event added!", Toast.LENGTH_SHORT).show();
                finish();
            } else { // if there was somehow an error say that we couldn't add
                Toast.makeText(getApplicationContext(), "Unable to add Event!", Toast.LENGTH_SHORT).show();
            }
        }else{ // if we are editing
            int updates = writeEventDB.update(EventDB.EventTable.TABLE, values, "_id = ?",
                    new String[] {Float.toString(eventToEdit.getEventID())}); // update the value based on the ID of the eventTo edit
                                                                              // This method allows for events with the same name
            if(updates > 0){ // if updates were made display some toast and finish the activity
                Toast.makeText(getApplicationContext(), "Event Edited!", Toast.LENGTH_SHORT).show();
                finish();
            }else{ // if there was an error somehow display that
                Toast.makeText(getApplicationContext(), "Whoops! Something went wrong please try again", Toast.LENGTH_SHORT).show();

            }
        }
    }

    /**
     * This Adds the data from the UserEvent object into the proper fields to be edited
     */
    private void populateEdit(){
        TextView editName = findViewById(R.id.editNameText); // get Text views
        TextView editDesc = findViewById(R.id.editDescText);
        TextView editDate = findViewById(R.id.editDateText);
        TextView editTime = findViewById(R.id.editTimeText);

        editName.setText(eventToEdit.getEventName()); // set text views
        editDate.setText(eventToEdit.getEventDate());
        editDesc.setText(eventToEdit.getEventDescription());
        editTime.setText(eventToEdit.getEventTime());
    }

    //On Cancel Button Clicked
    public void onCancelClick(View view){
        new YesNoDialog("Are you sure you want to cancel any changes?").show(getSupportFragmentManager(), YesNoDialog.TAG);
    }

    @Override
    public void onDialogPositiveClick(DialogFragment dialog) {
        finish(); // if the user clicked yes when being asked if they want to cancel we just go back to the previous activity
    }

    @Override
    public void onDialogNegativeClick(DialogFragment dialog) {
        //Do nothing
    }
}