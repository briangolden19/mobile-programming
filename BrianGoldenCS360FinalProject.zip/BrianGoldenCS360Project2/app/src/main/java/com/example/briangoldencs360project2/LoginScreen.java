package com.example.briangoldencs360project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.briangoldencs360project2.data.LoginDB;

public class LoginScreen extends AppCompatActivity {
    //load loginDB helper
    private LoginDB loginDBHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);
        loginDBHelper = new LoginDB(getApplicationContext()); // load our helper for LoginDB
    }

    //Runs when login button is clicked
    public void loginButton(View view){
        SQLiteDatabase loginDb = loginDBHelper.getReadableDatabase(); // gets readable DB

        //Raw SQL query. In large scale production this should be checked for SQL injection issues
        String sql = "select * from " + LoginDB.LoginTable.TABLE + " where " + LoginDB.LoginTable.COL_NAME + " = ?";
        TextView userText = findViewById(R.id.usernameText); // get text view username
        TextView passText = findViewById(R.id.editTextTextPassword); // get textview password
        String username = userText.getText().toString(); // get the text of the username
        String password = passText.getText().toString(); // get the text of the password

        if(username.isEmpty()){ // if the username section is empty notify user and escape method
            new OKDialog("Please enter a valid username!").show(getSupportFragmentManager(), OKDialog.TAG);
            return;
        }
        if(password.isEmpty()){ // if password section is empty notify user and escape method
            new OKDialog("Please enter something in the password field!").show(getSupportFragmentManager(), OKDialog.TAG);
            return;
        }
        Cursor cursor = loginDb.rawQuery(sql, new String[] {username}); // get the Cursor of the raw SQL query
        String dbPass = ""; // this will hold the password from the DB to do a PW check
        boolean found = false; // used to make sure the username was in the DB
        if(cursor.moveToFirst()){ // loop to check for the username and get the password from the DB
            do{
                if(cursor.getString(1).equals(username)){
                    found = true;
                    dbPass = cursor.getString(2);
                }
            }while(cursor.moveToNext());
        }
        cursor.close();
        if(found){
            if(dbPass.equals(password)) { // if we found the username and the password is correct we can move to the next screen
                Intent myIntent = new Intent(LoginScreen.this, GridScreen.class);
                LoginScreen .this.startActivity(myIntent);
            }else{ // otherwise error out
                new OKDialog("Your Password is wrong, please try again!").show(getSupportFragmentManager(), OKDialog.TAG);
            }
        }else{ // if the username wasnt found let the user know to create the account to move forward
            new OKDialog("Login Info Not Found. Please create an account").show(getSupportFragmentManager(), OKDialog.TAG);
        }
    }

    //Will run when create account button is clicked
    public void createAccount(View view){
        SQLiteDatabase loginDBWrite = loginDBHelper.getWritableDatabase(); // get a writable DB to add entries
        SQLiteDatabase loginDBRead = loginDBHelper.getReadableDatabase(); // get a readable DB to make sure the account doesnt exist
        TextView userText = findViewById(R.id.usernameText); // get textview for username
        TextView passText = findViewById(R.id.editTextTextPassword); // get textview for password
        String username = userText.getText().toString(); // get the string from the text view
        String password = passText.getText().toString(); // get the string from the text view

        if(username.isEmpty()){ // if the username box is empty throw an error message
            new OKDialog("Please enter a valid username!").show(getSupportFragmentManager(), OKDialog.TAG);
            return;
        }
        if(password.isEmpty()){ // if the password is empty also throw an error message
            new OKDialog("Please enter something in the password field!").show(getSupportFragmentManager(), OKDialog.TAG);
            return;
        }

        // SQL raw query string
        String sql = "select * from " + LoginDB.LoginTable.TABLE + " where " + LoginDB.LoginTable.COL_NAME + " = ?";
        Cursor cursor = loginDBRead.rawQuery(sql, new String[] {username}); // run the query on the username
        boolean found = false; // used for checks to see if the username exists
        if(cursor.moveToFirst()){
            do{
                if(cursor.getString(1).equals(username)){
                    found = true; // if we found it set to true
                }
            }while(cursor.moveToNext());
        }
        cursor.close();
        if(found){ // If the username was found in the DB then we need to throw an error
            new OKDialog("This Username Already Exists!!").show(getSupportFragmentManager(), OKDialog.TAG);
        }else{ // otherwise we can put the new user into the DB
            ContentValues values = new ContentValues(); // used for entering values into the DB
            values.put(LoginDB.LoginTable.COL_NAME,username); // add username to vales
            values.put(LoginDB.LoginTable.COL_PASSWORD,password); //add plaintext password to values
            long added = loginDBWrite.insert(LoginDB.LoginTable.TABLE,null,values); // write to DB
            if(added != -1){ // show message saying the account was added
               Toast.makeText(getApplicationContext(), "Account added!", Toast.LENGTH_SHORT).show();
           }else{ // show message saying there was something that went wrong
                Toast.makeText(getApplicationContext(), "Unable to add account!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}