package com.example.briangoldencs360project2;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

/**
 * This is the class to help with creating Dialog Fragments that have a Yes or No option
 */
public class YesNoDialog extends DialogFragment {
    public static String TAG = "YNDialog";
    private String displayMessage;

    public interface YesNoDialogListener { // This is used in classes that use this dialog.
        // I found this to be the best way to get which option was picked
       public void onDialogPositiveClick(DialogFragment dialog);
       public void onDialogNegativeClick(DialogFragment dialog);
    }
    YesNoDialogListener listener;


    public YesNoDialog(String m){
        super();
        displayMessage = m;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            listener = (YesNoDialogListener) context;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException("This must implement NoticeDialogListener");
        }
    }


    @NonNull
    public Dialog onCreateDialog(Bundle savedInstance){
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(displayMessage)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        listener.onDialogPositiveClick(YesNoDialog.this);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        listener.onDialogNegativeClick(YesNoDialog.this);
                    }
                });
        // Create the AlertDialog object and return it
        return builder.create();
    }
}
