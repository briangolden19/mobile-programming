package com.example.briangoldencs360project2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.briangoldencs360project2.data.EventDB;

import java.util.ArrayList;

public class GridScreen extends AppCompatActivity implements YesNoDialog.YesNoDialogListener {

    public static ArrayList<UserEvent> userEvents; // this is public and static so that we can access it in other methods
    // I was trying to pass data via Intent but that does not work with complex objects
    private int removalEvent; // this is the ID of the event we want to remove. It was the easiest way to pass this data
                              // in between the onRemoveClicked and the positive dialog click

    @Override
    public void onDialogPositiveClick(DialogFragment dialog) { // the user clicked yes when being asked to remove an event
        UserEvent remove = userEvents.get(removalEvent - 1); // we get the event based on ID
        EventDB eventDBHelper = new EventDB(getApplicationContext()); // snag our DB helper
        SQLiteDatabase writeDB = eventDBHelper.getWritableDatabase(); // get the writable DB
        int rows = writeDB.delete(EventDB.EventTable.TABLE,  "_id =?"
                ,new String[] {Float.toString(remove.getEventID())}); // run our delete query
        if(rows > 0) // if we removed something then display a message saying so
            Toast.makeText(getApplicationContext(), "Event Removed!", Toast.LENGTH_SHORT).show();
        else // it should never get here because of how the app is setup but if it does we display an error message
            Toast.makeText(getApplicationContext(), "Unable to Remove Event", Toast.LENGTH_SHORT).show();

        loadDB(); // reload the Database
        modifyRows(); // reload the rows so they update nice
    }

    @Override
    public void onDialogNegativeClick(DialogFragment dialog) {
        //Dont do anything
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_screen);
        disableEditing(); // This is a mess, don't look here
        loadDB(); // load the database on activity load
        modifyRows(); // modify the rows based on how many activities there are
    }

    @Override
    protected void onResume(){ // when we resume reload the DB and modify the rows as needed
        super.onResume();
        loadDB();
        modifyRows();
    }

    // On permissions click
    public void onPermissionsClick(View view){
        Intent myIntent = new Intent(GridScreen.this, permissionsActivity.class);
        GridScreen.this.startActivity(myIntent); // switch screens
    }

    // On Add Event
    public void onAddEvent(View view){
        Intent myIntent = new Intent(GridScreen.this, editEvent.class);
        GridScreen.this.startActivity(myIntent); // switch screens
    }

    //when a remove button is clicked
    public void onRemoveEvent(View view){
        String fullName = getResources().getResourceName(view.getId()); // get the full view name
        String name = fullName.substring(fullName.lastIndexOf("/") + 1); // get just the ID I made
        int rowID = Character.getNumericValue(name.charAt(3)); // get the row number based on my naming schema
        removalEvent = rowID; // set this regardless of yes or no
        new YesNoDialog("Are you sure you want to delete?").show(getSupportFragmentManager(), YesNoDialog.TAG); // display our dialog
    }


    // when an edit button is clicked
    public void onEditEvent(View view){
        Intent myIntent = new Intent(GridScreen.this,editEvent.class);
        String fullName = getResources().getResourceName(view.getId());
        String name = fullName.substring(fullName.lastIndexOf("/") + 1); // get the full view name and bring it down to the ID I set
        int rowID = Character.getNumericValue(name.charAt(3)); // get the row number based on my naming schema
        myIntent.putExtra("EventID",rowID - 1); //send the row ID (minus 1 for the arraylist) to the intent as an extra
        GridScreen.this.startActivity(myIntent);
    }

    /**
     * This loads the Database and puts the data into an ArrayList for easy use
     */
    private void loadDB(){
        userEvents = new ArrayList<>(); // every time this loads we clear our ArrayList
        EventDB eventDBHelper = new EventDB(getApplicationContext()); // load the Helper
        SQLiteDatabase eventDB = eventDBHelper.getReadableDatabase(); // get the readable DB
        Cursor cursor = eventDB.rawQuery("select * from " + EventDB.EventTable.TABLE,null); // get all the things
        if (cursor.moveToFirst()) {
            do{ // go through our DB creating user event objects on each go round
                userEvents.add(new UserEvent(cursor.getLong(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4)));
            }while (cursor.moveToNext());
        }
        cursor.close(); // always close your cursors
    }

    /**
     * This is a helper to enable or disable buttons based on if there is events for their given row
     */
    private void modifyRows(){
        int i;
        for(i = 0; i < userEvents.size(); i++){
            enableButtons(i ,true);
            addDataToRow(i, userEvents.get(i));
        }
        for (; i < 8; i++){
            enableButtons(i,false);
            addDataToRow(i,new UserEvent(-1,"","","",""));
        }
    }

    // This is a helper method to enable buttons if there is data in the row
    private void enableButtons(int i ,boolean enable){
        Button edit;
        Button remove;
        switch (i){
            case 0:
                edit = findViewById(R.id.row1EditBut);
                remove = findViewById(R.id.row1RemoveBut);
                edit.setEnabled(enable);
                remove.setEnabled(enable);
                break;
            case 1:
                edit = findViewById(R.id.row2EditBut);
                remove = findViewById(R.id.row2RemoveBut);
                edit.setEnabled(enable);
                remove.setEnabled(enable);
                break;
            case 2:
                edit = findViewById(R.id.row3EditBut);
                remove = findViewById(R.id.row3RemoveBut);
                edit.setEnabled(enable);
                remove.setEnabled(enable);
                break;
            case 3:
                edit = findViewById(R.id.row4EditBut);
                remove = findViewById(R.id.row4RemoveBut);
                edit.setEnabled(enable);
                remove.setEnabled(enable);
                break;
            case 4:
                edit = findViewById(R.id.row5EditBut);
                remove = findViewById(R.id.row5RemoveBut);
                edit.setEnabled(enable);
                remove.setEnabled(enable);
                break;
            case 5:
                edit = findViewById(R.id.row6EditBut);
                remove = findViewById(R.id.row6RemoveBut);
                edit.setEnabled(enable);
                remove.setEnabled(enable);
                break;
            case 6:
                edit = findViewById(R.id.row7EditBut);
                remove = findViewById(R.id.row7RemoveBut);
                edit.setEnabled(enable);
                remove.setEnabled(enable);
                break;
            case 7:
                edit = findViewById(R.id.row8EditBut);
                remove = findViewById(R.id.row8RemoveBut);
                edit.setEnabled(enable);
                remove.setEnabled(enable);
                break;
        }
    }

    // Helper method to add data to rows
    private void addDataToRow(int i, UserEvent event){
        TextView name;
        TextView time;
        TextView desc;
        switch (i){
            case 0:
                name = findViewById(R.id.eventNameRow1);
                time = findViewById(R.id.eventTimeRow1);
                desc = findViewById(R.id.eventDescRow1);
                name.setText(event.getEventName());
                time.setText(event.getEventDate());
                desc.setText(event.getEventDescription());
                break;
            case 1:
                name = findViewById(R.id.eventNameRow2);
                time = findViewById(R.id.eventTimeRow2);
                desc = findViewById(R.id.eventDescRow2);
                name.setText(event.getEventName());
                time.setText(event.getEventDate());
                desc.setText(event.getEventDescription());
                break;
            case 2:
                name = findViewById(R.id.eventNameRow3);
                time = findViewById(R.id.eventTimeRow3);
                desc = findViewById(R.id.eventDescRow3);
                name.setText(event.getEventName());
                time.setText(event.getEventDate());
                desc.setText(event.getEventDescription());
                break;
            case 3:
                name = findViewById(R.id.eventNameRow4);
                time = findViewById(R.id.eventTimeRow4);
                desc = findViewById(R.id.eventDescRow4);
                name.setText(event.getEventName());
                time.setText(event.getEventDate());
                desc.setText(event.getEventDescription());
                break;
            case 4:
                name = findViewById(R.id.eventNameRow5);
                time = findViewById(R.id.eventTimeRow5);
                desc = findViewById(R.id.eventDescRow5);
                name.setText(event.getEventName());
                time.setText(event.getEventDate());
                desc.setText(event.getEventDescription());
                break;
            case 5:
                name = findViewById(R.id.eventNameRow6);
                time = findViewById(R.id.eventTimeRow6);
                desc = findViewById(R.id.eventDescRow6);
                name.setText(event.getEventName());
                time.setText(event.getEventDate());
                desc.setText(event.getEventDescription());
                break;
            case 6:
                name = findViewById(R.id.eventNameRow7);
                time = findViewById(R.id.eventTimeRow7);
                desc = findViewById(R.id.eventDescRow7);
                name.setText(event.getEventName());
                time.setText(event.getEventDate());
                desc.setText(event.getEventDescription());
                break;
            case 7:
                name = findViewById(R.id.eventNameRow8);
                time = findViewById(R.id.eventTimeRow8);
                desc = findViewById(R.id.eventDescRow8);
                name.setText(event.getEventName());
                time.setText(event.getEventDate());
                desc.setText(event.getEventDescription());
                break;
        }
    }

    // after trying to use the XML and looking at all the documentation,
    // this is the best solution I could find
    // Literally no XML modifications could disable editing or focus.
    // This method makes me sad but it is necessary for the way I want my app to function
    private void disableEditing(){
        TextView current = findViewById(R.id.eventNameRow1);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventNameRow2);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventNameRow3);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventNameRow4);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventNameRow5);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventNameRow6);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventNameRow7);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventNameRow8);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventTimeRow1);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventTimeRow2);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventTimeRow3);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventTimeRow4);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventTimeRow5);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventTimeRow6);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventTimeRow7);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventTimeRow8);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventDescRow1);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventDescRow2);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventDescRow3);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventDescRow4);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventDescRow5);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventDescRow6);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventDescRow7);
        current.setKeyListener(null);
        current.setOnClickListener(null);
        current = findViewById(R.id.eventDescRow8);
        current.setKeyListener(null);
        current.setOnClickListener(null);
    }
}