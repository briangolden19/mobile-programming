package com.example.briangoldencs360project2;

public class UserEvent {
    private final String name;
    private final String date;
    private final String time;
    private final String description;
    private final float _id;

    /**
        This holds the user Events. It's more of a helper class but it was necessary
     */
    public UserEvent(float id, String n, String d, String t, String desc){
        _id = id;
        name = n;
        date = d;
        time = t;
        description = desc;
    }
    // below just gets all of the fields as needed
    public String getEventName(){
        return name;
    }
    public String getEventDate(){
        return date;
    }
    public String getEventTime(){
        return time;
    }
    public String getEventDescription(){
        return description;
    }
    public float getEventID() { return _id; }
}
